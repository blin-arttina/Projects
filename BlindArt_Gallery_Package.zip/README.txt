Blind Art – Gallery Package

Files:
- index.html – full gallery page with 41 pairs
- blind-art.css – dark theme styling
- images/ – put your images here using the filenames in manifest.csv
- manifest.csv – titles mapped to expected filenames

Filenames:
- {slug}-original.jpg
- {slug}-enhanced.jpg

Example:
- purple-peaks-original.jpg
- purple-peaks-enhanced.jpg

Duplicates:
If the same artwork exists twice (paper + canvas), keep one set of originals.

Anti-Download:
Basic protections are enabled (no right-click; key shortcuts blocked).
